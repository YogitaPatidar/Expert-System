/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author lenovo
 */
@WebServlet(urlPatterns = {"/ansQuestionSer"})
public class ansQuestionSer extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         PrintWriter out=response.getWriter();
        try{
           HttpSession session=request.getSession();
           
           Class.forName("com.mysql.jdbc.Driver");
           Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/expertsystem","root","");
           Statement st=conn.createStatement();
           int x=st.executeUpdate("insert into solution(questionId,answer,expertId,userId) values('1','"+request.getParameter("ans")+"','"+(String)session.getAttribute("expertID")+"','"+request.getParameter("uid")+"')");
           if(x!=0){
               response.sendRedirect("answerUser.jsp");
           }
           else{
               response.sendRedirect("answerUser.jsp?q=error...");
           }
          }
        catch(Exception ex){
            out.print(ex.getMessage().toString());
        }
    }
}
